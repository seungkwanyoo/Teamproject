package org.zerock.domain.cart.dto;

import lombok.Data;

@Data
public class CartDto {
	private int userId;
	private int prodId;
}

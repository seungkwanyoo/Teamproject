package org.zerock.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.zerock.domain.product.dto.CheckoutProdDto;
import org.zerock.domain.user.User;
import org.zerock.domain.user.dto.CheckoutRespDto;
import org.zerock.domain.user.dto.JoinUser;

import org.zerock.domain.user.dto.UpdateUser;

import org.zerock.service.ProductService;
import org.zerock.service.UserService;
import org.zerock.util.Logout;
import org.zerock.util.SHA256;
import org.zerock.util.Script;

@WebServlet("/user")
public class UserController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private UserService userService;
	
    public UserController() {
        super();
        this.userService = new UserService();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
	}
	
	protected void doProcess(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String cmd = request.getParameter("cmd");
		RequestDispatcher dis;
		System.out.println(request.getRequestURI());
		
		if (cmd.equals("joinForm")) {
			dis = request.getRequestDispatcher("/user/join.jsp");
			dis.forward(request, response);
			
		} else if (cmd.equals("loginForm")) {
			dis = request.getRequestDispatcher("/user/login.jsp");
			dis.forward(request, response);
			
		} else if (cmd.equals("logout")) {
			HttpSession session = request.getSession();
			int result = 500;
			// 회원 로그아웃 시작
			if (session.getAttribute("principal") != null) {
				System.out.println("logout pincipal : " + session.getAttribute("principal"));
				result = 200;
			}
			// 회원 로그아웃 끝
			// 로그아웃 공통 시작
			if (result == 200) {
				session.invalidate();
				dis = request.getRequestDispatcher("/index.jsp");
				dis.forward(request, response);
			} else {
				Script.back(response, "로그아웃 실패");
			}
			// 로그아웃 공통 끝
			
		} else if (cmd.equals("checkAgain")) {
			dis = request.getRequestDispatcher("/user/checkAgain.jsp");
			dis.forward(request, response);
			
		} else if (cmd.equals("mypage")) {
			HttpSession session = request.getSession();
			User userEntity = (User) session.getAttribute("principal");
			int userId = userEntity.getId();
			String password = SHA256.toSHA256(request.getParameter("password"));
			
			User userUpdate = userService.회원정보수정요청(userId, password);
			if (userUpdate == null) {
				Script.back(response, "비밀번호가 틀렸습니다.");
			} else {
				request.setAttribute("userUpdate", userUpdate);
				dis = request.getRequestDispatcher("/user/mypage.jsp");
				dis.forward(request, response);
			}
			
		} else if (cmd.equals("update")) {
			int userId = Integer.parseInt(request.getParameter("id"));
			String inputPassword = request.getParameter("password");
			UpdateUser updateUser = null;
			if (userService.비밀번호변경여부조회(userId, inputPassword)) {
				updateUser = UpdateUser.builder()
						.id(Integer.parseInt(request.getParameter("id")))
						.email(request.getParameter("email"))
						.phone(request.getParameter("phone"))
						.address(request.getParameter("address"))
						.password(SHA256.toSHA256(request.getParameter("password")))
						.build();
			} else {
				updateUser = UpdateUser.builder()
						.id(Integer.parseInt(request.getParameter("id")))
						.email(request.getParameter("email"))
						.phone(request.getParameter("phone"))
						.address(request.getParameter("address"))
						.password(request.getParameter("password"))
						.build();
			}
			int result = userService.회원정보수정(updateUser);
			
			if (result == 1) {
				dis = request.getRequestDispatcher("/index.jsp");
				dis.forward(request, response);
			} else {
				Script.back(response, "회원정보 수정에 실패하였습니다.");
			}
			
			
		} else if (cmd.equals("join")) {
			JoinUser joinUser = JoinUser.builder()
					.name(request.getParameter("name"))
					.username(request.getParameter("username"))
					.email(request.getParameter("email"))
					.phone(request.getParameter("phone"))
					.address(request.getParameter("address"))
					.password(SHA256.toSHA256(request.getParameter("password")))
					.build();
			
			int result = userService.회원가입(joinUser);
			if (result == 1) {
				User userEntity = userService.로그인(joinUser.getUsername(), joinUser.getPassword());
				HttpSession session = request.getSession();
				session.setAttribute("principal", userEntity);
				dis = request.getRequestDispatcher("/index.jsp");
				dis.forward(request, response);
			} else {
				Script.back(response, "회원가입 실패");
			}
			
		} else if (cmd.equals("login")) {
			User userEntity = userService.로그인(request.getParameter("username"), SHA256.toSHA256(request.getParameter("password")));
			if (userEntity == null) {
				Script.back(response, "로그인 실패");
			} else {
				HttpSession session = request.getSession();
				session.setAttribute("principal", userEntity);
				dis = request.getRequestDispatcher("/index.jsp");
				dis.forward(request, response);
			}
			
		} else if (cmd.equals("directBuy")) {
			int userId = Integer.parseInt(request.getParameter("userId"));
			CheckoutRespDto userInfo = userService.구매회원정보(userId);
			request.setAttribute("userInfo", userInfo);
			
			int prodId = Integer.parseInt(request.getParameter("prodId"));
			ProductService productService = new ProductService();
			CheckoutProdDto prodInfo = productService.구매상품정보(prodId);
			request.setAttribute("prodInfo", prodInfo);
			
			dis = request.getRequestDispatcher("/user/check-out.jsp");
			dis.forward(request, response);
			
		} else if (cmd.equals("cartBuy")) {
			int userId = Integer.parseInt(request.getParameter("userId"));
			CheckoutRespDto userInfo = userService.구매회원정보(userId);
			request.setAttribute("userInfo", userInfo);
			
			List<Integer> cartList = userService.장바구니번호리스트(userId);
			ProductService productService = new ProductService();
			List<CheckoutProdDto> prodList = productService.구매상품정보(cartList);
			request.setAttribute("prodList", prodList);

			dis = request.getRequestDispatcher("/user/check-out.jsp");
			dis.forward(request, response);

		}
		
	}

}

package org.zerock.service;

import java.util.List;

import org.zerock.domain.cart.CartDao;
import org.zerock.domain.cart.dto.CartAllDto;
import org.zerock.domain.cart.dto.CartDto;

public class CartService {
	private CartDao cartDao;
	
	public CartService() {
		this.cartDao = new CartDao();
	}
	
	public boolean 장바구니여부(int userId, int prodNo) {
		return cartDao.isCart(userId, prodNo);
	}
	
	public int 장바구니등록(CartDto cartDto) {
		return cartDao.addCart(cartDto);
	}
	
	public int 장바구니해제(CartDto cartDto) {
		return cartDao.rmvCart(cartDto);
	}
	
	public List<CartAllDto> 장바구니불러오기(int userId) {
		return cartDao.findByUserId(userId);
	}
	
}

package org.zerock.service;

import java.util.List;

import org.zerock.domain.BoardVO3;
import org.zerock.domain.Criteria3;

public interface BoardService3 {
	
	public void register3(BoardVO3 board);
	
	// 입력받은 BoardVO의 형식중에서 bno를 매개변수로 글을 읽어오겠다 ! ㅋ 
	public BoardVO3 get3(Long bno);
	
	public boolean modify3(BoardVO3 board);
	
	public boolean remove3(Long bno);
	
//	public List<BoardVO> getList();
	
	public List<BoardVO3> getList3(Criteria3 cri);
	
	public int getTotal3(Criteria3 cri);
	
}

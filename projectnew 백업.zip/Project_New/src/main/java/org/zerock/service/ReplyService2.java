package org.zerock.service;

import java.util.List;

import org.zerock.domain.Criteria2;
import org.zerock.domain.ReplyPageDTO2;
import org.zerock.domain.ReplyVO2;

public interface ReplyService2 {
	
	public int register2(ReplyVO2 vo);
	
	public ReplyVO2 get2(Long rno);
	
	public int modify2(ReplyVO2 vo);
	
	public int remove2(Long rno);
	
	public List<ReplyVO2> getList2(Criteria2 cri, Long bno);
	
	public ReplyPageDTO2 getListPage2(Criteria2 cri, Long bno);
	
	
	
}

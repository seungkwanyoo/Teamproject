package org.zerock.service;

import java.util.List;

import org.zerock.domain.Criteria3;
import org.zerock.domain.ReplyPageDTO3;
import org.zerock.domain.ReplyVO3;

public interface ReplyService3 {
	
	public int register3(ReplyVO3 vo);
	
	public ReplyVO3 get3(Long rno);
	
	public int modify3(ReplyVO3 vo);
	
	public int remove3(Long rno);
	
	public List<ReplyVO3> getList3(Criteria3 cri, Long bno);
	
	public ReplyPageDTO3 getListPage3(Criteria3 cri, Long bno);
	
	
	
}

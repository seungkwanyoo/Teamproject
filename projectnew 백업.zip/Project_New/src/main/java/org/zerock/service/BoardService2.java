package org.zerock.service;

import java.util.List;

import org.zerock.domain.BoardVO2;
import org.zerock.domain.Criteria2;

public interface BoardService2 {
	
	public void register2(BoardVO2 board);
	
	// 입력받은 BoardVO의 형식중에서 bno를 매개변수로 글을 읽어오겠다 ! ㅋ 
	public BoardVO2 get2(Long bno);
	
	public boolean modify2(BoardVO2 board);
	
	public boolean remove2(Long bno);
	
//	public List<BoardVO> getList();
	
	public List<BoardVO2> getList2(Criteria2 cri);
	
	public int getTotal2(Criteria2 cri);
	
}

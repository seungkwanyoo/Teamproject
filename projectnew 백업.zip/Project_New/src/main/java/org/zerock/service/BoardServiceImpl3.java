package org.zerock.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.zerock.domain.BoardVO3;
import org.zerock.domain.Criteria3;
import org.zerock.mapper.BoardMapper3;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
// @AllArgsConstructor

//BoardServiceImpl는 BoardService를 구현
public class BoardServiceImpl3 implements BoardService3 {
	
	
	// Spring 4.3 이상에서는 자동처리
	@Setter(onMethod_ = {@Autowired})
	private BoardMapper3 mapper;

	@Override
	public void register3(BoardVO3 board) {
		log.info("글등록 처리 테스트 입니다 =======> " + board);
		
		mapper.insertSelectKey3(board); // DB에 저장하는역할
		
	}

	@Override
	public BoardVO3 get3(Long bno) {
		log.info("글상세조회 기능이 구현됩니다!" + bno);
		return mapper.read3(bno);
	}

	@Override
	public boolean modify3(BoardVO3 board) {
		log.info("글 수정이 처리 됩니다" + board);
		return mapper.update3(board) == 1;
	}

	@Override
	public boolean remove3(Long bno) {
		log.info("글 삭제 기능을 처리합니다!" + bno);
		return mapper.delete3(bno) == 1;
	}

//	@Override
//	public List<BoardVO> getList() {
//		log.info("글목록 조회 기능을 처리합니다!");
//		return mapper.getList();
//	}

	@Override
	public List<BoardVO3> getList3(Criteria3 cri) {
		log.info("pageNum와 amount를 고려한 getList() 글 목록 조회! : " + cri);
		return mapper.getListWithPaging3(cri);
	}

	@Override
	public int getTotal3(Criteria3 cri) {
		log.info("전체 데이터 숫자를 카운트해서 알려줍니다!");
		return mapper.getTotalCount3(cri);
	}
	
	

	
	
}

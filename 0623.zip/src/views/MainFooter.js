import React from "react";
import "../css/MainFooter.css"
import facebook from "../images/facebook.svg"
import github from "../images/github.svg"
import instargram from "../images/instargram.svg"
import twiter from "../images/twiter.svg"
import Dropdown from 'react-bootstrap/Dropdown';




const MainFooter = () =>{
   return (
      <>
         <div className="MainFooter">
               <ul className="Footer_Ul_Li">
                  <li><a href="#">회사소개</a></li>
                  <li><a href="#">광고/문의</a></li>
                  <li><a href="#">이용약관</a></li>
                  <li><a href="#">개인정보방침</a></li>
                  <li><a href="#">무단수집하지마셈</a></li>
                  <li><a href="#">고객센터</a></li>
                  <li><a href="#">최신영화</a></li>
                  <li><a href="#">인기영화</a></li>
                  <li><a href="#">지켜보고있다...</a></li>
               </ul>
               <article className="Footer_Article">
                  <section className="Footer_Section">
                     <dl>서울특별시 구로구 구로동 구로구로구로</dl>
                     <dl>대표 : 유승관</dl>
                     <dl>부대표 : 차승혁</dl>
                     <dl>전화번호 : 00-000-000</dl>
                     <dl>팀원들 : 안예인, 박미르, 김정진, 김재동</dl>
                  </section>
                  <section className="Footer_Section_T">
                     <div className="FooterArticle_T_Img">
                        <img src={facebook} />
                        <img src={github} />
                        <img src={instargram} />
                        <img src={twiter} />
                     </div>
                  </section>
               </article>
            </div>
      </>
   )
}
export default MainFooter;
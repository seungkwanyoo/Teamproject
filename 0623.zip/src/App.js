import React, { Component } from 'react';
import ReactBootstrapNavbars from './components/ReactBootstrapNavbars';
import { Route, Switch } from "react-router-dom";
import { BrowserRouter } from 'react-router-dom/cjs/react-router-dom.min';

// 컴포넌트 아래에 다음의 import 구문을 넣어주시기 바랍니다.
import 'bootstrap/dist/css/bootstrap.css'; 
import Home from './components/Home';
import Location from './components/Location';
import CommunityBoard from './components/CommunityBoard';
import inputForm from "./views/inputForm";
import MainFooter from './views/MainFooter';
import Dynamic from './components/dynamic';
import movie_expected from './components/movie_expected';
import Review from './components/Review';
import Ticket from './components/Ticket';
import Reviewcont from './components/Reviewcont';


class App extends Component {
  render() {
    return (
      <div>
      <BrowserRouter>
        <ReactBootstrapNavbars />
        <Switch>
          <Route exact path="/" component={Home} />
          <Route exact path="/movie_expected" component={movie_expected} />
          <Route exact path="/Ticket" component={Ticket} />
          <Route exact path="/Location" component={Location} />
          <Route exact path="/Reviewcont"  component={Reviewcont} />
          <Route exact path="/communityboard" component={CommunityBoard} />
        </Switch>
        <Route exact path="/Review" component={Dynamic} />
        <Route exact path="/Review" component={Review} />
        <Route exact path="/aa/:crud" component={inputForm} />
        <MainFooter />
      </BrowserRouter>
      </div>
    );
  }
}

export default App;
import React from "react";
import Container from "react-bootstrap/Container";
import Carousel from 'react-bootstrap/Carousel';
import 'bootstrap/dist/css/bootstrap.css';
import '../css/home.css';
import Tab from 'react-bootstrap/Tab';
import Tabs from 'react-bootstrap/Tabs';
import '../css/movie_expected.css';

// Carousels 맨 위에 Examples
// https://react-bootstrap.netlify.app/docs/components/carousel/

const Home = () => {
    return(
      <>
        <div className="wrapper">
            <Container>
            <div className="firstcont">
                <div className="carouselcont">
                <Carousel>
      <Carousel.Item>
        <img
          className="d-block w-100"
          src="./images/movie1.jpg"
          alt="First slide"
        />
        <Carousel.Caption>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img
          className="d-block w-100"
          src="./images/movie2.jpg"
          alt="Second slide"
        />
        <Carousel.Caption>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img
          className="d-block w-100"
          src="./images/movie4.jpg"
          alt="Third slide"
        />
        <Carousel.Caption>
        </Carousel.Caption>
      </Carousel.Item>
    </Carousel>
          
                </div>
            
       

        {/* // Tabbed components 맨 위에 Examples
    // https://react-bootstrap.netlify.app/docs/components/tabs/ */}

    <div className="secondcont">
     <Tabs
      defaultActiveKey="home"
      id="uncontrolled-tab-example"
      className="mb-3"
    >
      <Tab eventKey="notice" title="공지사항" className="inform">
      <ul>
            <li><a>방송통신위원회 공지사항 01</a><span className='date'>2023-06-18</span></li>
            <li><a>방송통신위원회 공지사항 02</a><span className='date'>2023-06-19</span></li>
            <li><a>방송통신위원회 공지사항 03</a><span className='date'>2023-06-20</span></li>
            <li><a>방송통신위원회 공지사항 04</a><span className='date'>2023-06-21</span></li>
            <li><a>방송통신위원회 공지사항 05</a><span className='date'>2023-06-22</span></li>                    
     </ul>
      </Tab>
      <Tab eventKey="information" title="방송국정보" className="inform">
      <ul>
            <li><a href="http://www.kbs.co.kr" target="_blank">KBC 대한방송공사 고객센터 : 02-1234-5678</a><span className='date'>2023-06-18</span></li>
            <li><a>SBO 공영방송공사 고객센터 : 02-1234-5679</a><span className='date'>2023-06-19</span></li>
            <li><a>MBS 문화생활방송 고객센터 : 02-1234-5680</a><span className='date'>2023-06-20</span></li>
            <li><a>TVY 궁금방송공사 고객센터 : 02-1234-5681</a><span className='date'>2023-06-21</span></li>
            <li><a>KCO 세계방송공사 고객센터 : 02-1234-5682</a><span className='date'>2023-06-22</span></li>                       
     </ul>
      </Tab>
    </Tabs>
    </div>
    </div>
    </Container>
    </div>

    </>
    );
};

export default Home;
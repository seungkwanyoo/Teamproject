import Carousel from 'react-bootstrap/Carousel';
import Container from 'react-bootstrap/Container';
import { Link } from "react-router-dom";
import movie1 from "./image/movie1.jpg";
import movie2 from "./image/movie2.jpg";
import movie3 from "./image/movie3.jpg";
import movie4 from "./image/movie4.jpg";
import movie5 from "./image/movie5.jpg";
import movie6 from "./image/movie6.jpg";
import "../css/review.css";

function Review() {
  return (
    <Container>
    <Carousel className='carou'>
      <Carousel.Item interval={3000}>
      <Link to = "/Reviewcont"><img src={movie1} className='img'/></Link>
      </Carousel.Item>
      <Carousel.Item interval={3000}>
      <img src={movie2}  className='img'/>
      </Carousel.Item>
      <Carousel.Item interval={3000}>
      <img src={movie3}  className='img'/>
      </Carousel.Item>
      <Carousel.Item interval={3000}>
      <img src={movie4}  className='img'/>
      </Carousel.Item>
      <Carousel.Item interval={3000}>
      <img src={movie5}  className='img'/>
      </Carousel.Item>
      <Carousel.Item interval={3000}>
      <img src={movie6}  className='img'/>
      </Carousel.Item>
    </Carousel>
    </Container>
  );
}

export default Review;

import React from "react";
import Myimage from './image/ava.svg'
import Myimage2 from './image/ava2.svg'
import Myimage3 from './image/ava3.svg'
import "../css/reviewCont.css";
    const Reviewcont = () =>{

        return (
            <div>
                <div class="card mb-3">
                <h3 class="card-header">영화 정보</h3>
                <div class="card-body">
                    <h4 class="card-title">아바타</h4>
                    <h6 class="card-subtitle text-muted">: 물의 길</h6>
                </div>
                <div className="myimgs">
                <img src={Myimage} class="d-block user-select-none" height="500px" />
                <img src={Myimage2} class="d-block user-select-none" height="500px" />
                <img src={Myimage3} class="d-block user-select-none" height="500px" />
                </div>
                
                <div class="card-body">
                    <p class="card-text">신비로운 판도라 행성의 광활한 바다를 배경으로 하는 《아바타》의 후속작.
10여 년이 흐른 후 하늘의 사람들이 돌아오며 시작된 설리 가족의 새로운 여정과 싸움을 그렸다.</p>
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item">장르: 밀리터리SF, 액션, 스릴러, 판타지</li>
                    <li class="list-group-item">감독: 제임스 카메론</li>
                    <li class="list-group-item">주연: 샘 워딩턴, 조 샐다나, 시고니 위버 </li>
                </ul>
                <div class="card-body">
                    <a href="https://youtu.be/7Q70_m-59O8" class="card-link">티저 예고편</a>
                    <a href="https://youtu.be/kihrFxwdMb4" class="card-link">메인 예고편</a>
                </div>
                <div class="card-footer text-muted">
                    평점 : ⭐⭐⭐⭐⭐(5/5)
                </div>
                </div>
              

            </div>
        );
    
}

export default Reviewcont;
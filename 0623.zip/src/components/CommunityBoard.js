import { useState } from 'react';
import ReactHtmlParser from 'html-react-parser';
import '../css/communityBoard.css'; 

function CommunityBoard() {
  const [movieContent, setMovieContent] = useState({
    title: '',
    content: ''
  });

  // 입력
  const [viewContent, setViewContent] = useState([]);

  // 제목
  const getValue = e => {
    const { name, value } = e.target;
    setMovieContent({
      ...movieContent,
      [name]: value
    })
    console.log(movieContent);
  };

  // 내용
  const getText = e => {
    const { name, value } = e.target;
    setMovieContent({
      ...movieContent,
      [name]: value
    })
    console.log(movieContent);
  }
  return (
    <div className="App">
      <h1>Community Board</h1>
      <div className='movie-container'>
        {viewContent.map(element =>
          <div style={{ border: '1px solid #333'}}>
            <h2>{element.title}</h2>
            <div>
              {ReactHtmlParser(element.content)}
            </div>
          </div>
          )}
        </div>
      <div className='form-wrapper'>
        <input className='title-input'
          type='text'
          placeholder='제목'
          onChange={getValue}
          name='title' 
           />
        <textarea className='text-area'
         placeholder='내용'
         onChange={getText}
         name='content'
         ></textarea>
      </div>
      <button
        className='submit-button'
        onClick={() => {
          setViewContent(viewContent.concat({...movieContent}));}
        }>입력</button>
    </div>
  );
}

export default CommunityBoard;
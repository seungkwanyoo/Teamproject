import React from "react";
import { Link } from "react-router-dom";


const ViewButton03 = () => {
    return (
        <>
        
            
            <Link to="/aa/Update">
                <button>최근 게시글 수정</button>
            </Link>
          
        </>
    );
};
export default ViewButton03;
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import '../css/common.css'; 
import { Link } from 'react-router-dom/cjs/react-router-dom.min';

function ReactBootstrapNavbars() {
  return (
    <Navbar className="navbar" expand="lg">
      <Container>
        <Navbar.Brand href="/" className='logo'> <img src='/images/logo.png' alt='로고이미지' /></Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="me me-auto">
            <Nav >
              <Link to="/movie_expected" className='bar text-white'>  상영 예정작 </Link>
            </Nav>
            <Nav >
              <Link to="/Review" className='bar text-white'>  리뷰 작성 </Link>
            </Nav>
            <Nav>
              <Link to="/Ticket" className='bar text-white' > 영화 예매</Link>
            </Nav>
            <Nav>
            <Link to="/Location" className='bar text-white' > 오시는 길</Link>
            </Nav>
            
            <NavDropdown title="게시판" id="basic-nav-dropdown">
              <NavDropdown.Item href="/aa/View">자유게시판</NavDropdown.Item>
              <NavDropdown.Divider />
              <NavDropdown.Item href="/communityboard">커뮤니티게시판</NavDropdown.Item>
            </NavDropdown>
          </Nav>
          {/* https://react-bootstrap.netlify.app/docs/forms/form-control */}
          {/* d-flex는 flex 적용 의미함 */}
          <Form className='d-flex'>
           {/* .me-2는 margin-end 0.5rem Size 적용 의미함 */}
           {/* aria-label은 값에 간결한 설명을 제공해서, 문자열을 통해 현재 엘리먼트의 기능/목적을 설명함 */}
          <Form.Control type="search" className='me-2' placeholder="영화를 검색하세요!" aria-label='Search' />
          {/* https://react-bootstrap.netlify.app/docs/components/buttons */}
          <Button variant="outline-dark btn-light" className='searchBtn'>검색</Button>
          </Form>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default ReactBootstrapNavbars;
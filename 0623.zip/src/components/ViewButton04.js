import React from "react";
import { Link } from "react-router-dom";


const ViewButton04 = () => {
    return (
        <>
        
    
            <Link to="/aa/Delete">
                <button>최근 게시글 삭제</button>
            </Link>
           
        </>
    );
};
export default ViewButton04;
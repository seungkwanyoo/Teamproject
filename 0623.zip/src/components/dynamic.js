import React from "react";
import { Tabs, Tab } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";
import ViewButton from "./ViewButton";
import ViewButton03 from "./ViewButton03";
import ViewButton04 from "./ViewButton04";
import Container from 'react-bootstrap/Container';
import "../css/dyamic.css";


export default function Dynamic() {

  
    return (
      <Container>
      <Tabs fill className="mb-3 dyamic">
     
        <Tab eventKey="home" title="리뷰등록">
        <ViewButton className="viewbtn"/>
        </Tab>
      
        <Tab eventKey="profile" title="리뷰수정">
        <ViewButton03 className="viewbtn"/>
      
        </Tab>
        <Tab eventKey="contact" title="리뷰삭제">
        
        <ViewButton04 className="viewbtn"/> 
      
        </Tab>
      </Tabs>
      </Container>  
      
      
    );
  }
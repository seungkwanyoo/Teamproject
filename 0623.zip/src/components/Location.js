import React, { useEffect, useState } from 'react';
import "../css/location.css"

const { kakao } = window;

const Location = () => {
    const [map,setMap] = useState(null);

    //처음 지도 그리기
    useEffect(()=>{
        const container = document.getElementById('map');
        const options = { center: new kakao.maps.LatLng(33.450701, 126.570667) };
        const kakaoMap = new kakao.maps.Map(container, options);

      // 마커가 표시될 위치입니다 
      const markerPosition  = new kakao.maps.LatLng(33.450701, 126.570667); 

      // 마커를 생성합니다
      const marker = new kakao.maps.Marker({
          position: markerPosition
      });

      // 마커가 지도 위에 표시되도록 설정합니다
      marker.setMap(kakaoMap);
    },[])

    return (
        <div>
            <div id="map"></div>
        </div>
    );
};

export default Location;
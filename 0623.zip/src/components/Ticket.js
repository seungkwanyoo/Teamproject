import React from "react";
import main1 from "../images/main1.jpg";
import main2 from "../images/main2.jpg";
import main3 from "../images/main3.jpg";
import main4 from "../images/main4.jpg";
import main5 from "../images/main5.jpg";
import "../css/ticket.css";

const Ticket = () => {
    return(
       
        <div className="post">

        <div>
        <a href="https://www.cgv.co.kr/"><img src={main1} className="post1"></img> </a>
            <p className="post2">엘리멘탈</p>
            <div className="nuder">2023ㆍ미국</div>
            <div className="nuder1">예매율24% ㆍ 누적 관객 69만명</div>
        </div>
        <div>
        <a href="https://www.cgv.co.kr/"><img src={main2} className="post1"></img></a>
            <p className="post2">범죄도시3</p>
            <div className="nuder">2023ㆍ한국</div>
            <div className="nuder1">예매율21% ㆍ 누적 관객 916만명</div>
        </div>
        <div>
        <a href="https://www.cgv.co.kr/">   <img src={main3} className="post1"></img></a> 
            <p className="post2">스파이더맨: 어크로스 더 유니버스</p>
            <div className="nuder">2023ㆍ미국</div>
            <div className="nuder1">예매율17% ㆍ 누적 관객 7만명</div>
        </div>
        <div>
        <a href="https://www.cgv.co.kr/">    <img src={main4} className="post1"></img></a>
            <p className="post2">귀공자</p>
            <div className="nuder">2023ㆍ 한국</div>
            <div className="nuder1">예매율16% ㆍ 누적 관객 9만명</div>
        </div>  

        <div>
        <a href="https://www.cgv.co.kr/">    <img src={main5} className="post1"></img></a>
            <p className="post2">명탐정코난:하이바라 아이</p>
            <div className="nuder">2023 ㆍ 일본</div>
            <div className="nuder1">예매율4.8% ㆍ 누적 관객 6만명</div>
        </div>  
        </div>

        
        
);
};


export default Ticket;
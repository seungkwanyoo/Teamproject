import React from "react";
import { Link } from "react-router-dom";
import "../css/btn.css";

const ViewButton = () => {
    return (
        <>
            <div className="btn1">
            <Link to="/aa/Insert">
                <button>글쓰기</button>
            </Link>
            </div>
           
        </>
    );
};
export default ViewButton;